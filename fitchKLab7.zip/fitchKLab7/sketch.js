let array1 = [];
let array2 = [];
let combinedArray = [];

function setup() {
  createCanvas(400, 400);
  background(255, 230, 240); 

  // Loop 
  for (let i = 0; i < 5; i++) {
    array1.push("A" + i);
    array2.push("B" + i); 
  }

  // Array method!
  array1.pop();        // gets rid of last thing
  array1.unshift("Start"); // adds to beginning

  array2.shift();      // gets rid of first
  array2.push("End");  // adds to end

  // Combining the array
  combinedArray = array1.concat(array2);
  console.log("Array 1:", array1);
  console.log("Array 2:", array2);
  console.log("Combined Array:", combinedArray);

  // Random value???
  let rand1 = random(array1);
  let rand2 = random(array2);
  let randBoth = random(combinedArray);

  // Stuff on canvas
  fill(80);
  textSize(14);

  text("Array 1: " + array1.toString(), 20, 50);
  text("Array 2: " + array2.toString(), 20, 100);

  text("Random 1: " + rand1, 20, 180);
  text("Random 2: " + rand2, 20, 220);
  text("Random 1 & 2: " + randBoth, 20, 260);
}