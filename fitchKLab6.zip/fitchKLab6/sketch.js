// Positions of circles
let xPositions = [];

function setup() {
  createCanvas(400, 400);

  for (let i = 0; i < 10; i++) {
    xPositions[i] = random(width);
  }

  console.log("Array length is: " + xPositions.length);
}

function draw() {
  background(255, 220, 240); // pink BG

  for (let i = 0; i < xPositions.length; i++) {

    fill(255, 105, 180); // pink circles
    noStroke();

    // Draw circle using the array value
    circle(xPositions[i], 50 + i * 30, 25);

    // Create move by increasing x position
    xPositions[i] = xPositions[i] + 1;

    // Reset circle to left side if it goes off screen
    if (xPositions[i] > width) {
      xPositions[i] = 0;
    }
  }

  // Set one value in the array to the mouse X position
  xPositions[0] = mouseX;
}