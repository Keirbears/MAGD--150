// I chose to do a nice greeting card
// bg.png is the bg image and main.png is the main image (flower)

let bg;
let img;

function preload() {
  bg = loadImage("assets/bg.png");     // Background image
  img = loadImage("assets/main.png");  // Main image
}

function setup() {
  createCanvas(400, 400);
  textFont("Arial");
  textAlign(CENTER, CENTER);
}

function draw() {
  // soft pink background (in case image doesn't load)
  background(255, 200, 230);

  // Bg image 
  image(bg, 0, 0, width, height);

  // The main image (in middle & scales with mouse)
  push();
  translate(width / 2, height / 2);

  let s = map(mouseX, 0, width, 0.5, 1.5);
  scale(s);

  imageMode(CENTER);
  image(img, 0, 0, 150, 150);
  pop();

  // 2nd use of img ( it follows mouse )
  image(img, mouseX, mouseY, 60, 60);

  // The text
  fill(255);       
  stroke(200, 130, 180);
  strokeWeight(2);

  textSize(28);
  text("Get Better Soon!", width / 2, 300);

  // smaller text 
  noStroke();
  fill(100);

  textSize(14);
  text(
    "Wishing you fast recovery, and lots of love.",
    50,
    320,
    300,
    60
  );
}